package uk.ac.aber.clg11.tsp.ga;

public abstract class GAGene {
	
	public GAGene() {
		
	}

}
